#!/bin/bash
glib-compile-schemas schemas